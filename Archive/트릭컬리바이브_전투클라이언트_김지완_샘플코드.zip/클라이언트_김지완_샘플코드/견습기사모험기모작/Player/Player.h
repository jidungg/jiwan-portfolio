#pragma once
#include "Playable.h"
#include "AnimEventReceiver.h"
#include "Interactable.h"
#include "Gravity.h"


BEGIN(Engine)
class CAnimEventGenerator;
class CCollider; // test
class CModelObject;
class CLight_Target;
class CActor_Dynamic;
END
BEGIN(Client)
class CCarriableObject;
class CDraggableObject;
class CStateMachine;
class IInteractable;
class CPortal;
class CBook;
class CStopStamp;
class CBombStamp;
class CDetonator;
class CPlayerBomb;
class CZetPack;
class CPlayerBody;
class CDefenderPlayer;
class CPlayerRifle;
class CTurnBookEffect;
enum class PLAYER_2D_ITEM_ID
{
	FATHER_BODY,
	FATHER_WING,
	FATER_HEAD,
	LAST
};
enum PLAYER_INPUT
{
	PLAYER_INPUT_MOVE,
	PLAYER_INPUT_JUMP,
	PLAYER_INPUT_ATTACK,
	PLAYER_INPUT_ROLL,
	PLAYER_INPUT_THROWSWORD,
	PLAYER_INPUT_THROWOBJECT,
	PLAYER_INPUT_SNEAK,
	PLAYER_INPUT_SPINATTACK,
	PLAYER_INPUT_SPINCHARGING,
	PLAYER_INPUT_SPINLAUNCH,
	PLAYER_INPUT_REVIVE,
	PLAYER_INPUT_TURNBOOK_LEFT,
	PLAYER_INPUT_TURNBOOK_RIGHT,
	PLAYER_INPUT_TILTBOOK_LEFT,
	PLAYER_INPUT_TILTBOOK_RIGHT,
	PLAYER_INPUT_TURNBOOK_END,
	PLAYER_INPUT_START_STAMP,
	PLAYER_INPUT_KEEP_STAMP,
	PLAYER_INPUT_CANCEL_STAMP,
	PLAYER_INPUT_DETONATE,
	PLAYER_INPUT_ZETPROPEL,
	PLAYER_INPUT_LAST
};

typedef struct tagPlayerInputResult
{
	_vector vMoveDir = {0,0,0};
	_vector vDir = { 0,0,0 };
	_bool bInputStates[PLAYER_INPUT_LAST] = {false,};

}PLAYER_INPUT_RESULT;
class CPlayer final : public CPlayable, public virtual  IAnimEventReceiver
{
public:
	enum PLAYER_SHAPE_USE
	{
		INTERACTION = SHAPE_USE::SHAPE_USE_LAST,
		BODYGUARD,
		PLAYER_SHAPE_USE_LAST
	};
	typedef struct tagAttackTriggerDesc
	{
		_float2 vExtents = { 100.f,100.f };
		_float2 vOffset = { 0.f,0.f };
	}ATTACK_TRIGGER_DESC;
	enum ATTACK_TYPE
	{
		ATTACK_TYPE_NORMAL1,
		ATTACK_TYPE_NORMAL2,
		ATTACK_TYPE_NORMAL3,
		ATTACK_TYPE_SPIN,
		ATTACK_TYPE_JUMPATTACK,
		ATTACK_TYPE_THKROWSWORD,
		ATTACK_TYPE_LAST
	};
	enum PLAYER_MODE
	{
		PLAYER_MODE_SWORD,
		PLAYER_MODE_SNEAK,
		PLAYER_MODE_ZETPACK,
		PLAYER_MODE_CYBERJOT,
		PLAYER_MODE_LAST
	};

	enum PLAYER_PART
	{
		PLAYER_PART_BODY = 0,
		PLAYER_PART_SWORD = 1,
		PLAYER_PART_GLOVE,
		PLAYER_PART_STOP_STMAP,
		PLAYER_PART_BOMB_STMAP,
		PLAYER_PART_RIFLE,
		PLAYER_PART_DETONATOR = 6,
		PLAYER_PART_ZETPACK,
		PLAYER_PART_VISOR,
		PLAYER_PART_TURNBOOKEFFECT,
		PLAYER_PART_CYBERCURSOR,
		PLAYER_PART_LAST
	};

	enum PLAYER_MAIN_EQUIP
	{
		PLAYER_MAIN_EQUIP_SWORD = PLAYER_PART_SWORD,
		PLAYER_MAIN_EQUIP_GLOVE,
		PLAYER_MAIN_EQUIP_STOP_STMAP,
		PLAYER_MAIN_EQUIP_BOMB_STMAP,
		PLAYER_MAIN_EQUIP_RIFLE,
		PLAYER_MAIN_EQUIP_LAST
	};
	enum PLAYER_SUB_EQUIP
	{
		PLAYER_SUB_EQUIP_DETONATOR = PLAYER_PART_DETONATOR,
		PLAYER_SUB_EQUIP_ZETPACK,
		PLAYER_SUB_EQUIP_VISOR,
	};

	enum STATE
	{
		IDLE,
		RUN,
		JUMP_UP,
		JUMP_DOWN,
		ATTACK,
		JUMP_ATTACK,
		ROLL,
		THROWSWORD,
		PICKUPOBJECT,
		THROWOBJECT,
		LAYDOWNOBJECT,
		CLAMBER,
		SPINATTACK,
		DIE,
		START_PORTAL,
		START_CANNON_PORTAL,
		JUMPTO_PORTAL,
		EXIT_PORTAL,
		ELECTRIC,
		TURN_BOOK,
		EVICT,
		LUNCHBOX,
		DRAG,
		STAMP,
		BOMBER,
		ERASE_PALM,
		GET_ITEM,
		TRANSFORM_IN,
		CYBER_IDLE,
		CYBER_FLY,
		CYBER_DASH,
		CYBER_HIT,
		RETRIVE_SWORD,
		MOJAM,
		PULL,
		ENGAGE_BOSS,
		BACKROLL,

		STATE_LAST
	};
	enum class ANIM_STATE_2D
	{
		JOT_GATEPASS,
		JOT_HANDEVICT,
		JOT_HANDEVICT_SMUSHLOOP,
		PLAYER_C06_END,
		PLAYER_C06_IDLE01,
		PLAYER_C06_IDLE01TRANSITION,
		PLAYER_C06_IDLE01_INTO,
		PLAYER_C06_IDLE02,
		PLAYER_C06_IDLE03,
		PLAYER_C06_LOOKUP,
		PLAYER_C08V02_END,
		PLAYER_C08V02_IDLE01,
		PLAYER_C08V02_IDLE02,
		PLAYER_C08V02_LOOKUPLEFT,
		PLAYER_C08V02_LOOKUPRIGHT,
		PLAYER_CLIFFCRUMBLE,
		PLAYER_CYBERJOTLITE_RUN_IDLE_TEMP,
		PLAYER_CYBERJOTLITE_RUN_RIGHT,
		PLAYER_CYBERJOTLITE_TRANSFORM,
		PLAYER_GIVEPOP,
		PLAYER_GIVEWAND,
		PLAYER_SLEEPING_LOOP,
		PLAYER_SLEEPING_WAKEUP,
		PLAYER_SLIPPINGV02_NOSWORD_DOWN,
		PLAYER_SLIPPINGV02_NOSWORD_RIGHT,
		PLAYER_SLIPPINGV02_NOSWORD_UP,
		PLAYER_SLIPPINGV02_SWORD_DOWN,
		PLAYER_SLIPPINGV02_SWORD_RIGHT,
		PLAYER_SLIPPINGV02_SWORD_UP,
		PLAYER_TUMBADANCEV03,
		PLAYER_MOJAM_MOJAM,
		PLAYER_MOJAM_MOJAM_C02_0910,
		PLAYER_MOJAM_MOJAM_C10_0910,
		JOT_GAMEOVER,
		JOT_GAMEOVER_LOOP,
		JOT_GAMEOVER_NOSWORD,
		JOT_GAMEOVER_NOSWORD_LOOP,
		JOT_LOOKUP_HOLD_RIGHT,
		JOT_LOOKUP_RIGHT,
		JOT_SURPRISE_HOLD_RIGHT,
		JOT_SURPRISE_RIGHT,
		JOT_TOIDLE_RIGHT,
		JUMP_IN_PLAYER_ZIPIN_DOWN,
		JUMP_IN_PLAYER_ZIPIN_RIGHT,
		JUMP_IN_PLAYER_ZIPIN_UP,
		JUMP_OUT_PLAYER_ZIPOUT_DOWN_EDIT,
		JUMP_OUT_PLAYER_ZIPOUT_RIGHT_EDIT,
		JUMP_OUT_PLAYER_ZIPOUT_UP_EDIT,
		PLAYER_ATTACK_DOWN,
		PLAYER_ATTACK_RIGHT,
		PLAYER_ATTACK_UP,
		PLAYER_ATTACKCOMBO_01_SS,
		PLAYER_ATTACKCOMBO_01_DOWN,
		PLAYER_ATTACKCOMBO_01_RIGHT,
		PLAYER_ATTACKCOMBO_01_UP,
		PLAYER_ATTACKCOMBO_03_SS,
		PLAYER_ATTACKCOMBO_03_DOWN,
		PLAYER_ATTACKCOMBO_03_RIGHT,
		PLAYER_ATTACKCOMBO_03_UP,
		PLAYER_ATTACKV02_SPIN_DOWN_LVL1,
		PLAYER_ATTACKV02_SPIN_DOWN_LVL2,
		PLAYER_ATTACKV02_SPIN_DOWN_LVL3,
		PLAYER_ATTACKV02_SPIN_DOWN_LVL4,
		PLAYER_ATTACKV02_SPIN_INTO_DOWN,
		PLAYER_ATTACKV02_SPIN_INTO_RIGHT,
		PLAYER_ATTACKV02_SPIN_INTO_UP,
		PLAYER_ATTACKV02_SPIN_RIGHT_LVL1,
		PLAYER_ATTACKV02_SPIN_RIGHT_LVL2,
		PLAYER_ATTACKV02_SPIN_RIGHT_LVL3,
		PLAYER_ATTACKV02_SPIN_RIGHT_LVL4,
		PLAYER_ATTACKV02_SPIN_UP_LVL1,
		PLAYER_ATTACKV02_SPIN_UP_LVL2,
		PLAYER_ATTACKV02_SPIN_UP_LVL3,
		PLAYER_ATTACKV02_SPIN_UP_LVL4,
		PLAYER_ATTACKV02_SS,
		PLAYER_BOOKENTER_DOWN,
		PLAYER_BOOKENTER_FALL_DOWN,
		PLAYER_BOOKENTER_FALL_RIGHT,
		PLAYER_BOOKENTER_FALL_UP,
		PLAYER_BOOKENTER_RIGHT,
		PLAYER_BOOKENTER_UP,
		PLAYER_BOOKEXIT_DOWN,
		PLAYER_BOOKEXIT_RIGHT,
		PLAYER_BOOKEXIT_UP,
		PLAYER_C06_CRUSHROOMGET,
		PLAYER_C06_CRUSHROOMGET_IDLE,
		PLAYER_C06_POWERUP_END,
		PLAYER_C06_RAISESWORD,
		PLAYER_C06_RAISESWORD_LOOP,
		PLAYER_C06_SWORDBEAM_LOOP,
		PLAYER_C06_SWORDBEAM_OUT,
		PLAYER_CANNON_CURL_CANCEL,
		PLAYER_CANNON_CURL_INTO,
		PLAYER_CANNON_CURL_SPIN,
		PLAYER_CANNONCHARGE_DOWN,
		PLAYER_CANNONCHARGE_RIGHT,
		PLAYER_CANNONCHARGE_UP,
		PLAYER_CARRY_IDLE_DOWN,
		PLAYER_CARRY_IDLE_RIGHT,
		PLAYER_CARRY_IDLE_RIGHT_SS,
		PLAYER_CARRY_IDLE_UP,
		PLAYER_CATCH_GLITCHBIRD,
		PLAYER_CATCH_GLITCHBIRD_OUTLINE,
		PLAYER_CYBERJOTLITE_BOOKEXIT_DOWN,
		PLAYER_DEATH_DOWN,
		PLAYER_DODGEROLL_DOWN_NOSWORD,
		PLAYER_DODGEROLL_DOWN_SINGLEROLLONLY,
		PLAYER_DODGEROLL_RIGHT_NOSWORD,
		PLAYER_DODGEROLL_RIGHT_SINGLEROLLONLY,
		PLAYER_DODGEROLL_UP_NOSWORD,
		PLAYER_DODGEROLL_UP_SINGLEROLLONLY,
		PLAYER_DROP_OBJECT_DOWN,
		PLAYER_DROP_OBJECT_RIGHT,
		PLAYER_DROP_OBJECT_SS,
		PLAYER_DROP_OBJECT_UP,
		PLAYER_ELECTROCUTE,
		PLAYER_HAPPY,
		PLAYER_IDLE_DOWN,
		PLAYER_IDLE_RIGHT,
		PLAYER_IDLE_SWORD_DOWN,
		PLAYER_IDLE_SWORD_RIGHT,
		PLAYER_IDLE_SWORD_UP,
		PLAYER_IDLE_UP,
		PLAYER_ITEM_RETRIEVE,
		PLAYER_ITEM_RETRIEVE_V02,
		PLAYER_JUMP_FALL_DOWN,
		PLAYER_JUMP_FALL_OBJECT_DOWN,
		PLAYER_JUMP_FALL_OBJECT_RIGHT,
		PLAYER_JUMP_FALL_OBJECT_UP,
		PLAYER_JUMP_FALL_RIGHT,
		PLAYER_JUMP_FALL_SWORD_DOWN,
		PLAYER_JUMP_FALL_SWORD_RIGHT,
		PLAYER_JUMP_FALL_SWORD_UP,
		PLAYER_JUMP_FALL_UP,
		PLAYER_JUMP_RISE_DOWN,
		PLAYER_JUMP_RISE_OBJECT_DOWN,
		PLAYER_JUMP_RISE_OBJECT_RIGHT,
		PLAYER_JUMP_RISE_OBJECT_UP,
		PLAYER_JUMP_RISE_RIGHT,
		PLAYER_JUMP_RISE_SWORD_DOWN,
		PLAYER_JUMP_RISE_SWORD_RIGHT,
		PLAYER_JUMP_RISE_SWORD_UP,
		PLAYER_JUMP_RISE_UP,
		PLAYER_JUMP_RISE_UP_,
		PLAYER_JUMPCARRY_RISE_DOWN,
		PLAYER_JUMPCARRY_RISE_UP,
		PLAYER_JUMPINGATTACK_FALL_DOWN,
		PLAYER_JUMPINGATTACK_FALL_RIGHT,
		PLAYER_JUMPINGATTACK_FALL_UP,
		PLAYER_JUMPINGATTACK_OUT_DOWN,
		PLAYER_JUMPINGATTACK_OUT_RIGHT,
		PLAYER_JUMPINGATTACK_OUT_UP,
		PLAYER_JUMPINGATTACK_RISE_DOWN,
		PLAYER_JUMPINGATTACK_RISE_RIGHT,
		PLAYER_JUMPINGATTACK_RISE_UP,
		PLAYER_KNOCKEDBACK_FLOOR,
		PLAYER_KNOCKEDBACK_INTO,
		PLAYER_KNOCKEDBACK_LOOP,
		PLAYER_KNOCKEDBACK_OUT,
		PLAYER_MOJAM_INTO,
		PLAYER_PICKUP_IDLE_DOWN,
		PLAYER_PICKUP_IDLE_RIGHT,
		PLAYER_PICKUP_IDLE_UP,
		PLAYER_PICKUP_OBJECT_DOWN,
		PLAYER_PICKUP_OBJECT_RIGHT,
		PLAYER_PICKUP_OBJECT_SS,
		PLAYER_PICKUP_OBJECT_UP,
		PLAYER_PULL_LOOP,
		PLAYER_PULL_OBJECT_DOWN,
		PLAYER_PULL_OBJECT_RIGHT,
		PLAYER_PULL_OBJECT_SS,
		PLAYER_PULL_OBJECT_UP,
		PLAYER_PUSH_OBJECT_DOWN,
		PLAYER_PUSH_OBJECT_RIGHT,
		PLAYER_PUSH_OBJECT_SS,
		PLAYER_PUSH_OBJECT_UP,
		PLAYER_ROLL_INTO,
		PLAYER_ROLL_LOOP,
		PLAYER_ROLL_OUT,
		PLAYER_RUN_DOWN,
		PLAYER_RUN_OBJECT_DOWN,
		PLAYER_RUN_OBJECT_RIGHT,
		PLAYER_RUN_OBJECT_UP,
		PLAYER_RUN_RIGHT,
		PLAYER_RUN_SWORD_DOWN,
		PLAYER_RUN_SWORD_RIGHT,
		PLAYER_RUN_SWORD_UP,
		PLAYER_RUN_UP,
		PLAYER_SWORD_RETRIEVE,
		PLAYER_SWORDTHROW_AIMLOOP_DOWN,
		PLAYER_SWORDTHROW_AIMLOOP_RIGHT,
		PLAYER_SWORDTHROW_AIMLOOP_UP,
		PLAYER_SWORDTHROW_INTO_DOWN,
		PLAYER_SWORDTHROW_INTO_RIGHT,
		PLAYER_SWORDTHROW_INTO_UP,
		PLAYER_SWORDTHROW_OUT_DOWN,
		PLAYER_SWORDTHROW_OUT_RIGHT,
		PLAYER_SWORDTHROW_OUT_UP,
		PLAYER_THROW_OBJECT_DOWN,
		PLAYER_THROW_OBJECT_RIGHT,
		PLAYER_THROW_OBJECT_UP,
		PLAYER_TRAPPED,
		PLAYER_ZIPLINE,
	};

	enum class ANIM_STATE_3D
	{
		LATCH_ANIM_BOOK_JUMP_FALL_RIGHT
		, LATCH_ANIM_BOOK_JUMP_LAND_RIGHT
		, LATCH_ANIM_IDLE_01
		, LATCH_ANIM_JUMP_LAND_02
		, LATCH_ANIM_JUMP_UP_02 = 4
		, LATCH_KNOCKED_DOWN_AND_EATEN_FROM_BEHIND_LATCH
		, LATCH_KNOCKED_DOWN_AND_EATEN_FROM_BEHIND_LOOP_LATCH
		, LATCH_KNOCKED_DOWN_AND_EATEN_FROM_FRONT_LATCH
		, LATCH_KNOCKED_DOWN_AND_EATEN_FROM_FRONT_LOOP_LATCH
		, LATCH_TURN_LEFT
		, LATCH_TURN_MID
		, LATCH_TURN_RIGHT
		, LATCH_ANIM_ATTACK_02_GT
		, LATCH_ANIM_ATTACK_03_GT
		, LATCH_ANIM_BOOK_JUMP_FALL_BACK_NEWRIG = 14 //å ������ �پ���?
		, LATCH_ANIM_BOOK_JUMP_FALL_FRONT_NEWRIG
		, LATCH_ANIM_BOOK_JUMP_FALL_LEFT_NEWRIG
		, LATCH_ANIM_BOOK_JUMP_INTO_BACK_NEWRIG
		, LATCH_ANIM_BOOK_JUMP_INTO_FRONT_GT
		, LATCH_ANIM_BOOK_JUMP_INTO_FRONT_NEWRIG
		, LATCH_ANIM_BOOK_JUMP_INTO_LEFT_NEWRIG
		, LATCH_ANIM_BOOK_JUMP_INTO_RIGHT_GT
		, LATCH_ANIM_BOOK_JUMP_INTO_RIGHT_NEWRIG
		, LATCH_ANIM_BOOK_JUMP_LAND_BACK_NEWRIG
		, LATCH_ANIM_BOOK_JUMP_LAND_FRONT_NEWRIG
		, LATCH_ANIM_BOOK_JUMP_LAND_LEFT_NEWRIG = 25
		, LATCH_ANIM_BOOKOUT_01_GT
		, LATCH_ANIM_CALL_GT
		, LATCH_ANIM_CALL_NEWRIG
		, LATCH_ANIM_CANON_FLY_GT
		, LATCH_ANIM_CANON_FLY_LAND_GT
		, LATCH_ANIM_CAUGHT_GT
		, LATCH_ANIM_CLAMBER_01_EDIT_NEWRIG
		, LATCH_ANIM_CLAMBER_01_GT
		, LATCH_ANIM_DIE_GT
		, LATCH_ANIM_DIE_NEWRIG
		, LATCH_ANIM_DODGE_GT
		, LATCH_ANIM_DRAGGED_BWD_GT
		, LATCH_ANIM_DRAGGED_FWD_GT_ANIM
		, LATCH_ANIM_IDLE_01_GT
		, LATCH_ANIM_IDLE_NERVOUS_01_GT
		, LATCH_ANIM_IDLE_NERVOUS_01_NEWRIG
		, LATCH_ANIM_IDLE_NERVOUS_TURN_01_GT
		, LATCH_ANIM_IDLE_NERVOUS_TURN_01_NEWRIG
		, LATCH_ANIM_ITEM_GET_GT
		, LATCH_ANIM_ITEM_GET_NEWRIG
		, LATCH_ANIM_JUMP_DOWN_01_NEWRIG = 46
		, LATCH_ANIM_JUMP_DOWN_02_GT
		, LATCH_ANIM_JUMP_DOWN_02_NEWRIG
		, LATCH_ANIM_JUMP_LAND_02_GT
		, LATCH_ANIM_JUMP_START_SHORT_GT
		, LATCH_ANIM_JUMP_START_SHORT_NEWRIG
		, LATCH_ANIM_JUMP_UP_02_GT
		, LATCH_ANIM_JUMPATTACK_RISE_GT = 53
		, LATCH_ANIM_LUNCHBOX_BACKFLIP_GT
		, LATCH_ANIM_LUNCHBOX_POSE_01_LOOP_GT
		, LATCH_ANIM_LUNCHBOX_POSE_02_LOOP_GT
		, LATCH_ANIM_PULL_GT
		, LATCH_ANIM_PULL_LEFT_GT
		, LATCH_ANIM_PULL_RIGHT_GT
		, LATCH_ANIM_PUSH_GT
		, LATCH_ANIM_PUTDOWN_GT
		, LATCH_ANIM_PUTDOWN_NEWRIG
		, LATCH_ANIM_REMOTE_HOLD
		, LATCH_ANIM_REMOTE_PUSH_GT
		, LATCH_ANIM_RUN_01_GT
		, LATCH_ANIM_RUN_SWORD_01_GT
		, LATCH_ANIM_SPIN_ATTACK_INTO_GT
		, LATCH_ANIM_SPIN_ATTACK_OUT_GT
		, LATCH_ANIM_SPIN_ATTACK_SPIN_LOOP_GT
		, LATCH_ANIM_SPRINT_01_NEWRIG
		, LATCH_ANIM_STAMP_ATTACK_EDIT_NEWRIG
		, LATCH_ANIM_STAMP_ATTACK_GT
		, LATCH_ANIM_STAMP_ERASE_GT
		, LATCH_ANIM_STAMP_HOLD_GT
		, LATCH_ANIM_STAMP_HOLD_NEWRIG
		, LATCH_ANIM_STAMP_PULLOUT_SHORT_GT
		, LATCH_ANIM_STAMP_PULLOUT_SHORT_GT_EDIT
		, LATCH_ANIM_STAMP_PULLOUT_SHORT_NEWRIG
		, LATCH_ANIM_STEALTH_RUN_GT
		, LATCH_ANIM_SWORDTHROW_AIM_GT = 80
		, LATCH_ANIM_SWORDTHROW_AIM_NEWRIG
		, LATCH_ANIM_SWORDTHROW_INTO_GT
		, LATCH_ANIM_SWORDTHROW_INTO_NEWRIG
		, LATCH_ANIM_SWORDTHROW_THROW_GT
		, LATCH_ANIM_SWORDTHROW_THROW_NEWRIG
		, LATCH_ANIM_TORCH_STRAFE_BACK_01_GT
		, LATCH_ANIM_TORCH_STRAFE_FWD_01_GT
		, LATCH_ANIM_TORCH_STRAFE_LEFT_01_GT
		, LATCH_ANIM_TORCH_STRAFE_RIGHT_01_GT
		, LATCH_ANIM_TRAILER_OUTBOOK_01_ANIM = 90
		, LATCH_CINE_D09_LB_INTRO_SH_01
		, LATCH_CINE_D09_LB_INTRO_SH_02
		, LATCH_CINE_D09_LB_INTRO_SH_03
		, LATCH_CINE_GAUNTLET_EVENT_SHOT_01_GT
		, LATCH_PICKUP_GT
		, LATCH_PICKUP_IDLE_GT
		, LATCH_PICKUP_IDLE_NEWRIG
		, LATCH_PICKUP_NEWRIG
		, LATCH_STEALTH_IDLE_GT
		, LATCH_THROW_NEWRIG
		, LATCH_ANIM_ATTACK_01_BLOCKED_GT_EDIT
		, LATCH_ANIM_ATTACK_01_GT_EDIT
		, LATCH_ANIM_JUMPATTACK_FALL = 103
		, LATCH_ANIM_JUMPATTACK_LAND_GT_EDIT
		, LATCH_ANIM_JUMPATTACK_RISE = 105
		, LATCH_CANNON
		, CYBERJOT_ANIM_DEATH
		, CYBERJOT_ANIM_FLYING_DOWN
		, CYBERJOT_ANIM_FLYING_DOWN_DASH
		, CYBERJOT_ANIM_FLYING_IDLE
		, CYBERJOT_ANIM_FLYING_LEFT
		, CYBERJOT_ANIM_FLYING_LEFT_DASH
		, CYBERJOT_ANIM_FLYING_RIGHT
		, CYBERJOT_ANIM_FLYING_RIGHT_DASH
		, CYBERJOT_ANIM_FLYING_UP
		, CYBERJOT_ANIM_FLYING_UP_DASH
		, CYBERJOT_ANIM_SHOOT
		, CYBERJOT_CINE_D09_LB_OUTRO
		, CYBERJOT_CINE_DO9_LB_ENGAGE_SH01
		, CYBERJOT_CINE_DO9_LB_ENGAGE_SH02
		, CYBERJOT_ANIM_HIT_EDIT
		, LATCH_ANIM_LAST
	};
private:
	CPlayer(ID3D11Device* _pDevice, ID3D11DeviceContext* _pContext);
	CPlayer(const CPlayer& _Prototype);
	virtual ~CPlayer() = default;

public:
	virtual HRESULT			Initialize_Prototype() override;
	virtual HRESULT			Initialize(void* _pArg) override;
	virtual void			Priority_Update(_float _fTimeDelta) override;
	virtual void			Update(_float _fTimeDelta) override;
	virtual void			Late_Update(_float _fTimeDelta) override;
	virtual HRESULT			Render() override;

public:
	virtual void OnContact_Enter(const COLL_INFO& _My, const COLL_INFO& _Other, const vector<PxContactPairPoint>& _ContactPointDatas) override;
	virtual void OnContact_Stay(const COLL_INFO& _My, const COLL_INFO& _Other, const vector<PxContactPairPoint>& _ContactPointDatas) override;
	virtual void OnContact_Exit(const COLL_INFO& _My, const COLL_INFO& _Other, const vector<PxContactPairPoint>& _ContactPointDatas) override;
	virtual void OnTrigger_Enter(const COLL_INFO& _My, const COLL_INFO& _Other)override;
	virtual void OnTrigger_Stay(const COLL_INFO& _My, const COLL_INFO& _Other)override;
	virtual void OnTrigger_Exit(const COLL_INFO& _My, const COLL_INFO& _Other)override;
	virtual void On_Collision2D_Enter(CCollider* _pMyCollider, CCollider* _pOtherCollider, CGameObject* _pOtherObject)override;
	virtual void On_Collision2D_Stay(CCollider* _pMyCollider, CCollider* _pOtherCollider, CGameObject* _pOtherObject)override;
	virtual void On_Collision2D_Exit(CCollider* _pMyCollider, CCollider* _pOtherCollider, CGameObject* _pOtherObject)override;

	virtual void On_Hit(CGameObject* _pHitter, _int _fDamg, _fvector _vForce) override;
	virtual HRESULT	Change_Coordinate(COORDINATE _eCoordinate, _float3* _pNewPosition = nullptr) override;
	virtual void On_Land() override;
	virtual void On_Change2DDirection(E_DIRECTION _eCurrentDir) override;
	virtual void On_StartAutoMove() override;
	virtual void On_EndAutoMove() override;
	void On_AnimEnd(COORDINATE _eCoord, _uint iAnimIdx);
	void On_Stop() override;
	void On_UnStop() override;
	void On_GainPlayerItem(_uint _eItem);
public:

	void Move_Attack_3D();
	void StampSmash();
	void Attack(CGameObject* _pVictim);
	void Detonate();
	void ErasePalm();

	void Move_Forward(_float fVelocity, _float _fTImeDelta);
	void Jump();
	void ThrowSword();
	//�÷��̾ ���������� ������ ������ ������Լ�
	void ThrowObject();
	//�÷��̾ ���������� ������ ��� ����� �Լ�
	HRESULT CarryObject(CCarriableObject* _pCarryingObject);
	//�÷��̾ �������������� ������ �������� ����� �Լ�
	HRESULT LayDownObject();
	void SpinAttack();
	void Add_Upforce(_float _fForce);
	PLAYER_INPUT_RESULT Player_KeyInput();
	PLAYER_INPUT_RESULT Player_KeyInput_Stamp();
	PLAYER_INPUT_RESULT Player_KeyInput_ControlBook();
	PLAYER_INPUT_RESULT Player_KeyInput_CyberJot();
	void Revive();
	void ReFuel();
	void ZetPropel(_float _fTimeDelta);
	void Shoot_Rifle(_fvector _vDirection);
	void Acquire_Item(PLAYER_2D_ITEM_ID _eItemID);

	_bool Check_ReplaceInteractObject(IInteractable* _pObj);

	void Start_Portal(CPortal* _pPortal);
	void JumpTo_Portal(CPortal* _pPortal);
	void Exit_Portal(CPortal* _pPortal);
	void Set_PlayingAnim(_bool _bPlaying);
	void Start_Invinciblity();
	void RetrieveSword();
	void CatchSword();

	void Start_Attack(ATTACK_TYPE _eAttackType);
	void End_Attack();
	void Flush_AttckedSet() { m_AttckedObjects.clear(); }
	void Equip_Part(PLAYER_PART _ePartId);
	void UnEquip_Part(PLAYER_PART _ePartId);
	void UnEquip_All();
	void Position_To_FrontCamera(_float _fDistance);
	void TransformToCyberJot(class CZip_C8* _pZip);
	// interact �Լ��� ȣ��Ǹ� true ��ȯ.
	INTERACT_RESULT Try_Interact(_float _fTimeDelta);

	//Get
	_bool Is_ZetPack_Idle();
	_bool Is_SneakMode() { return PLAYER_MODE_SNEAK == m_ePlayerMode; }
	_bool Is_SwordMode() { return PLAYER_MODE_SWORD == m_ePlayerMode; }
	_bool Is_ZetPackMode() { return PLAYER_MODE_ZETPACK == m_ePlayerMode; }
	_bool Is_CyvberJotMode() { return PLAYER_MODE_CYBERJOT == m_ePlayerMode; }
	_bool Is_ZetPackEquipped();
	_bool Is_Sneaking();//�Ҹ��� �ȳ��� true ���� false
	_bool Is_SwordHandling();
	_bool Is_CarryingObject() { return nullptr != m_pCarryingObject; }
	_bool Is_AttackTriggerActive();
	_bool Is_DetonationMode();
	_bool Is_Invincible();

	_bool Is_PlayingAnim();
	_bool Has_InteractObject() { return nullptr != m_pInteractableObject; }
	_float Get_UpForce();
	_float Get_AnimProgress();
	_float Get_HeadHeight() { return m_fHeadHeight; }

	_float Get_ArmHeight() { return m_fArmHeight; }
	_float Get_ArmLength() { return m_fArmLength; }
	_float Get_AirRotationSpeed() { return m_fAirRotateSpeed; }
	_float Get_AirRunSpeed() { return m_fAirRunSpeed; }
	_float Get_AirRunSpeed2D() { return m_f2DAirRunSpeed; }
	_float Get_MoveSpeed(COORDINATE _eCoord) { return COORDINATE_2D == _eCoord ? m_f2DMoveSpeed : m_f3DMoveSpeed; }
	_float Get_DragMoveSpeed(COORDINATE _eCoord) { return COORDINATE_2D == _eCoord ? m_f2DDragMoveSpeed : m_f3DDragMoveSpeed; }
	_float Get_PickupRange(COORDINATE _eCoord) { return COORDINATE_2D == _eCoord ? m_f2DPickupRange : m_f3DPickupRange; }	_int Get_AttackDamg() { return m_tStat.iDamg; }
	_float Get_3DFloorDistance() { return m_f3DFloorDistance; }
	_float Get_2DFloorDistance() { return m_f2DFloorDistance; }
	_float Get_AnimationTIme();
	_uint Get_SpinAttackLevel() { return m_iSpinAttackLevel; }
	_float Get_2DAttackForwardingSpeed() { return m_f2DAttackForwardSpeed; }
	_vector Get_CenterPosition();
	_vector  Get_HeadPosition();
	_vector Get_LookDirection();
	_vector Get_LookDirection(COORDINATE _eCoord);
	_vector Get_2DELookDirection();
	_vector Get_2DFLookDirection();
	_vector Get_3DTargetDirection() { return m_v3DTargetDirection; }
	_vector Get_ClamberEndPosition() { return m_vClamberEndPosition; }
	_vector Get_WallNormal() { return m_vWallNormal; }
	_vector Get_BodyPosition();
	_vector Get_AttackTargetDirection();
	IInteractable* Get_InteractableObject() { return m_pInteractableObject; }
	STATE Get_CurrentStateID();
	PLAYER_MODE Get_PlayerMode() { return m_ePlayerMode; }
	CController_Transform* Get_Transform() { return m_pControllerTransform; }
	CCarriableObject* Get_CarryingObject() { return m_pCarryingObject; }
	const _float4x4* Get_BodyWorldMatrix_Ptr() const;
	const _float4x4* Get_BodyWorldMatrix_Ptr(COORDINATE eCoord) const;
	CPlayerBody* Get_Body() { return m_pBody; }
	CPartObject* Get_PlayerPartObject(PLAYER_PART _ePartId) { return m_PartObjects[(_uint)_ePartId]; }
	CZetPack* Get_ZetPack() { return m_pZetPack; }
	_vector Get_RootBonePosition();
	//NORMAL_DIRECTION Get_PortalNormal() { return m_e3DPortalNormal; }
	const ATTACK_TRIGGER_DESC& Get_AttackTriggerDesc(ATTACK_TYPE _eAttackType, F_DIRECTION _eFDir) { return m_f2DAttackTriggerDesc[_eAttackType][(_uint)_eFDir]; }
	const SHAPE_DATA& Get_BodyShapeData() { return m_tBodyShapeData; }
	PLAYER_PART Get_CurrentStampType() { return m_eCurrentStamp; }
	CActor_Dynamic* Get_ActorDynamic();
	class CTurnBookEffect* Get_TurnBookEffect() { return m_pTurnBookEffect; }


	//Set
	void Switch_Animation(_uint _iAnimIndex);
	void Set_Animation(_uint _iAnimIndex);
	void Set_State(STATE _eState);
	void Set_Mode(PLAYER_MODE _eNewMode);
	void Set_MoveSpeed(_float _fSpeed, COORDINATE _eCoord) 
	{
		if (COORDINATE_2D == _eCoord)
			m_f2DMoveSpeed = _fSpeed;
		else
			m_f3DMoveSpeed = _fSpeed;
	}
	void Set_3DTargetDirection(_fvector _vDir);
	void Set_WallNormal(_fvector _vNormal) { m_vWallNormal = _vNormal; }
	void Set_ClamberEndPosition(_fvector _vPos) { m_vClamberEndPosition = _vPos; }
	void Set_SwordGrip(_bool _bForehand);
	void Set_Kinematic(_bool _bKinematic);
	void Set_PlatformerMode(_bool _bPlatformerMode);
	void Set_Upforce(_float _fForce);
	//��¥ �����͸� �����ϴ� �Լ�
	void Set_CarryingObject(CCarriableObject* _pCarryingObject);
	void Set_InteractObject(IInteractable* _pInteractable) { m_pInteractableObject = _pInteractable; }
	//	NORMAL_DIRECTION Set_PortalNormal(NORMAL_DIRECTION _eNormal) { return m_e3DPortalNormal = _eNormal; }
	void Set_GravityCompOn(_bool _bOn, CGravity::STATE _eGravityState = CGravity::STATE_FALLDOWN);
	void Set_CurrentStampType(PLAYER_PART _eStamp) { m_eCurrentStamp = _eStamp; }


private:
	void					Key_Input(_float _fTimeDelta);

private:
	HRESULT					Ready_Components();

	HRESULT					Ready_PartObjects();

public:
	virtual void			Enter_Section(const _wstring _strIncludeSectionName) override;
	virtual void			Exit_Section(const _wstring _strIncludeSectionName) override;
private:
	//Variables
	_float m_f3DCenterYOffset = 0.5f;
	_float m_f3DInteractLookOffset = 0.65f;
	_float m_f3DInteractRadius = 1.f;
	_float m_fHeadHeight = 1.f;
	_float m_fArmHeight = 0.75f; // ��Ÿ�� ���� ����
	_float m_fArmLength = 0.325f;// �� Ÿ�� ����
	_float m_fFootLength = 0.25f;
	_float m_fAttackForwardingForce = 12.f;
	_float m_fGroundRotateSpeed = 360.f;

	_float m_f3DLandAnimHeightThreshold = 0.6f;
	_float m_f3DJumpPower = 10.5f;
	_float m_fAirRotateSpeed = 360.f;
	_float m_fAirRunSpeed = 4.2f; // �� ������ AddFore�̹Ƿ� DeltaTime�� ������
	_float m_f3DMoveSpeed = 6.f;
	_float m_f3DDragMoveSpeed = 2.5f;

	_float m_f3DThrowObjectPower = 20.f;
	_float m_f3DPickupRange = 1.3f;
	_float m_f3DKnockBackPower = 10.f;


	_bool m_bAttackTrigger = false;


	_uint m_iSpinAttackLevel = 4;
	_vector m_vClamberEndPosition = { 0.f,0.f,0.f,1.f };//��Ÿ�� ���� ��ġ
	_vector m_vWallNormal = { 0.f,0.f,1.f,0.f };//������ ���� ����


	_float4x4 m_mat3DCarryingOffset = {};
	PLAYER_MODE m_ePlayerMode = PLAYER_MODE_SWORD;
	//NORMAL_DIRECTION m_e3DPortalNormal = NORMAL_DIRECTION::LAST; 


	//2D����
	_float m_f2DAttackForwardSpeed = 700.f;
	_float m_f2DMoveSpeed = 400.f;
	_float m_f2DDragMoveSpeed = 200.f;
	_float m_f2DJumpPower = 600.f;
	_float m_f2DPlatformerJumpPower = 1200.f;
	_float m_f2DCenterYOffset = 36.f;
	_float m_f2DInteractRange = 93.f;
	_float m_f2DThrowObjectPower = 900.f;
	_float m_f2DPickupRange = 80.f;
	_float m_f2DKnockBackPower = 700.f;
	_float m_f2DInteractOffset = 40.f;
	/* �¿� */
	_float m_f2DColliderBodyRadius = 20.f;
	/* �¿� */
	_float m_fInvincibleTIme = 1.5f;
	_float m_fInvincibleTImeAcc = 0.f;
	_bool m_bInvincible = false;

	ATTACK_TYPE m_eCurAttackType = ATTACK_TYPE_NORMAL1;
	ATTACK_TRIGGER_DESC m_f2DAttackTriggerDesc[ATTACK_TYPE_LAST][(_uint)F_DIRECTION::F_DIR_LAST];// = { 93.f, 93.f, 120.f };
	//ATTACK_TRIGGER_DESC_2D m_f2DAttackAngle[ATTACK_TYPE_LAST];// = { 110.f, 110.f,45.f };
	_float m_f2DAirRunSpeed = 300.f;

	//Components
	CStateMachine* m_pStateMachine = nullptr;
	CCollider* m_pBody2DColliderCom = nullptr;
	CCollider* m_pBody2DTriggerCom = nullptr;
	CCollider* m_pAttack2DTriggerCom = nullptr;

	//Parts
	class CPlayerSword* m_pSword = nullptr;
	CPlayerBody* m_pBody = nullptr;
	CModelObject* m_pBodyCyber2D = nullptr;

	CModelObject* m_pGlove = nullptr;
	CStopStamp* m_pStopStmap = nullptr;
	CBombStamp* m_pBombStmap = nullptr;
	PLAYER_PART m_eCurrentStamp = PLAYER_PART::PLAYER_PART_BOMB_STMAP;
	CDetonator* m_pDetonator = nullptr;
	CZetPack* m_pZetPack = nullptr;
	CPlayerRifle* m_pRifle = nullptr;

	//��Ÿ ����� ������Ʈ
	CCarriableObject* m_pCarryingObject = nullptr;
	set<CGameObject*> m_AttckedObjects;
	CGameObject* m_pAttackTarget = nullptr;
	IInteractable* m_pInteractableObject = nullptr;
	CBook* m_pBook = nullptr;
	CPlayerBomb* m_pBomb = nullptr;

	SHAPE_CAPSULE_DESC m_tBodyShapeDesc = {};
	SHAPE_DATA m_tBodyShapeData = {};

	// Turn Book �� �� Effect
	class CTurnBookEffect* m_pTurnBookEffect = { nullptr };



// CyberJot��
public:
	void Update_CyberJot(_float _fTimeDelta);
	//Get
	_vector Get_CyberPlanePosition() { return m_vCyberPlanePosition; }
	_float Get_CyberFlySpeed() { return m_f3DCyberFlySpeed; }
	_float Get_CyberDashSpeed() { return m_f3DCyberDashSpeed; }
	_float Get_CyberCurrentSpeed() { return m_f3DCyberCurrentSpeed; }
	_vector Get_CyberVelocity() { return m_vCyberPlaneVelocity; }
	_vector Get_CyberCursorPosition() { return  m_vCyberCursorBasePosition + m_vCyberCursorOffset; }
	_vector Get_CyberCursorWorldPosition() { return m_vCyberCursorWorldPosition; }
	//Set
	void Set_CyberVelocity(_vector _vMoveVelocity);
	void Move_CyberCursor(_vector _vMove);
private:
	CActor_Dynamic* m_pDynamicActor = nullptr;
	class CCyberCursor* m_pCyberCursor = nullptr;
	class CCamera_Target* m_pTargetCamera = nullptr;
	const _float4x4* m_pCameraTargetWorldMatrix = { nullptr };
	_float m_fDistanceFromCamearPlane = 7.5f;
	_vector m_vCyberPlanePosition = { 0.f,0.f };
	_vector m_vCyberPlaneMaxPosition = { 5.f,4.f};
	_vector m_vCyberPlaneMinPosition = { -5.f,-4.f};
	_vector m_vCyberPlaneDirection = { 0.f,0.f };
	_vector m_vCyberPlaneVelocity = { 0.f,0.f };
	_vector m_vCyberCursorOffset = { 0.f,0.f, 0.f };
	_vector m_vCyberCursorMaxOffset = { 4.f,4.f, 0.f};
	_vector m_vCyberCursorMinOffset = { -4.f,-4.f, 0.f };
	_vector m_vCyberCursorBasePosition = { 0.f,0.f, 0.f };
	_vector m_vCyberCursorWorldPosition = { 0.f,0.f, 0.f };
	_vector m_vTargetBoardMin = { -8.f,5.f };
	_vector m_vTargetBoardMax = { 8.f,25.f };
	_float m_f3DCyberCursorDistance = 40.f;
	_float m_f3DCyberCurrentSpeed = 0.f;
	_float m_f3DCyberFlySpeed = 6.f;
	_float m_f3DCyberDashSpeed = 25.f;
	_float m_f3DCyberLinearDamping = 75.f;
public:
	static CPlayer*		Create(ID3D11Device* _pDevice, ID3D11DeviceContext* _pContext);
	virtual CGameObject*	Clone(void* _pArg) override;
	virtual void			Free() override;

};
END
